require(["purchase"],function(purchase){
  purchase.purchaseProduct();
});

//run immediate functionalities