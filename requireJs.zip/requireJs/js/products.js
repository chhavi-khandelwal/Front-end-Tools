define(function(products) {
  console.log("Function : reserveProduct");
  return {
    reserveProduct: function() {
 
      return true;
    }
  }
});

//define modules for use in multiple locations