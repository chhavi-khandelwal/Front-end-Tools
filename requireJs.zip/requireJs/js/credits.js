define(["products"], function() {
  console.log("Function : getCredits");
 
  return {
    getCredits: function() {
      var credits = "100";
      return credits;
    }
  }
});

//define modules for use in multiple locations